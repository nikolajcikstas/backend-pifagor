
"""
EasyPay email receipt parser.
"""
import imaplib
import email
import os
import re
import logging
import socket
from datetime import datetime, timedelta
from email.utils import parsedate_to_datetime
from typing import List, Dict, Optional

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, cast, Date

logger = logging.getLogger(__name__)

IMAP_HOST = os.getenv("EMAIL_IMAP_HOST", "imap.gmail.com")
IMAP_PORT = int(os.getenv("EMAIL_IMAP_PORT", "993"))
EMAIL_USER = os.getenv("EMAIL_USER", "")
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD", "")
LESSON_PRICE = float(os.getenv("LESSON_PRICE", "40"))
IMAP_TIMEOUT = 15


def _normalize_name(value: str | None) -> str:
    value = (value or "").lower().replace("ё", "е")
    value = re.sub(r"[^a-zа-я0-9\s-]+", " ", value)
    value = re.sub(r"\s+", " ", value).strip()
    return value


def _name_tokens(value: str | None) -> list[str]:
    return [part for part in _normalize_name(value).replace("-", " ").split() if part]


def _edit_distance_limited(left: str, right: str, limit: int = 1) -> int:
    if abs(len(left) - len(right)) > limit:
        return limit + 1
    previous = list(range(len(right) + 1))
    for i, left_char in enumerate(left, 1):
        current = [i]
        row_min = i
        for j, right_char in enumerate(right, 1):
            cost = 0 if left_char == right_char else 1
            value = min(
                previous[j] + 1,
                current[j - 1] + 1,
                previous[j - 1] + cost,
            )
            current.append(value)
            row_min = min(row_min, value)
        if row_min > limit:
            return limit + 1
        previous = current
    return previous[-1]


def _token_close(left: str, right: str) -> bool:
    if left == right:
        return True
    if min(len(left), len(right)) < 5:
        return False
    return _edit_distance_limited(left, right, 1) <= 1


def _main_name_tokens_match(payer: list[str], stored: list[str]) -> bool:
    payer_main = payer[:2]
    stored_main = stored[:2]
    return (
        (_token_close(payer_main[0], stored_main[0]) and _token_close(payer_main[1], stored_main[1]))
        or (_token_close(payer_main[0], stored_main[1]) and _token_close(payer_main[1], stored_main[0]))
    )


def _same_person(payer_name: str, stored_name: str) -> bool:
    payer = _name_tokens(payer_name)
    stored = _name_tokens(stored_name)
    if len(payer) < 2 or len(stored) < 2:
        return False
    if "родитель" in stored:
        return False
    if not _main_name_tokens_match(payer, stored):
        return False
    if len(stored) >= 3 and len(payer) >= 3 and payer[2] != stored[2]:
        return False
    return True


def _single_token_owner(payer_name: str, stored_name: str) -> bool:
    payer = _name_tokens(payer_name)
    stored = _name_tokens(stored_name)
    if len(payer) != 1 or len(stored) < 2:
        return False
    if "родитель" in stored:
        return False
    return payer[0] in set(stored[:2])


def _full_name(user) -> str:
    if not user:
        return ""
    parts = [user.last_name, user.first_name, user.middle_name]
    return " ".join(part for part in parts if part).strip()


def _get_email_body(msg) -> str:
    body = ""
    if msg.is_multipart():
        for part in msg.walk():
            ct = part.get_content_type()
            cd = str(part.get("Content-Disposition", ""))
            if ct == "text/plain" and "attachment" not in cd:
                payload = part.get_payload(decode=True)
                if payload:
                    charset = part.get_content_charset() or "utf-8"
                    body += payload.decode(charset, errors="ignore")
    else:
        payload = msg.get_payload(decode=True)
        if payload:
            charset = msg.get_content_charset() or "utf-8"
            body = payload.decode(charset, errors="ignore")
    return body


def parse_easypay_receipt(text: str) -> Optional[Dict]:
    if "счет-заказа" not in text and "Итого оплачено" not in text:
        return None

    result: Dict = {}

    # Receipt number
    m = re.search(r"Номер счет-заказа\s*[:\s]*([\w\d]+)", text)
    if m:
        result["receipt_number"] = m.group(1).strip()

    # Payer full name — убираем суффикс BY
    m = re.search(r"ФИО:\s*([А-ЯЁа-яёA-Za-z]+(?:\s+[А-ЯЁа-яёA-Za-z]+){1,2})", text)
    if m:
        name = m.group(1).strip()
        name = re.sub(r'\s+BY\s*$', '', name).strip()
        result["payer_name"] = name
    else:
        return None

    # Amount — два формата
    amount = None
    m = re.search(r"Итого оплачено[^:]*:\s*([\d]+[,\.][\d]+)", text, re.IGNORECASE)
    if m:
        try:
            amount = float(m.group(1).replace(",", "."))
        except ValueError:
            pass
    if amount is None:
        m = re.search(r"Сумма счета:\s*([\d]+[,\.][\d]+)", text, re.IGNORECASE)
        if m:
            try:
                amount = float(m.group(1).replace(",", "."))
            except ValueError:
                pass
    if amount is None:
        return None
    result["amount"] = amount

    return result


def _fetch_raw_receipts() -> List[Dict]:
    if not EMAIL_USER or not EMAIL_PASSWORD:
        logger.warning("Email credentials not configured — skipping inbox check.")
        return []

    old_timeout = socket.getdefaulttimeout()
    socket.setdefaulttimeout(IMAP_TIMEOUT)

    parsed: List[Dict] = []
    mail = None
    try:
        mail = imaplib.IMAP4_SSL(IMAP_HOST, IMAP_PORT)
        mail.login(EMAIL_USER, EMAIL_PASSWORD)
        mail.select("INBOX")

        # Только письма за последние 7 дней — не сканируем весь ящик
        since_date = (datetime.now() - timedelta(days=7)).strftime("%d-%b-%Y")
        _, message_ids = mail.search(None, f'(SINCE {since_date})')

        ids = message_ids[0].split()
        logger.info("Found %d emails in last 7 days", len(ids))

        for uid in ids:
            try:
                _, data = mail.fetch(uid, "(RFC822)")
                if not data or data[0] is None:
                    continue
                raw = data[0][1]
                msg = email.message_from_bytes(raw)

                body = _get_email_body(msg)
                receipt = parse_easypay_receipt(body)
                if receipt is None:
                    continue

                date_header = msg.get("Date", "")
                try:
                    receipt["payment_date"] = parsedate_to_datetime(date_header)
                except Exception:
                    receipt["payment_date"] = datetime.utcnow()

                receipt["raw_text"] = body[:3000]
                parsed.append(receipt)

            except Exception as e:
                logger.error("Failed to parse email uid=%s: %s", uid, e)

    except Exception as e:
        logger.error("IMAP connection error: %s", e)
    finally:
        if mail:
            try:
                mail.close()
                mail.logout()
            except Exception:
                pass
        socket.setdefaulttimeout(old_timeout)

    return parsed


async def _resolve_payer_children(payer_name: str, db: AsyncSession) -> list[int]:
    """Сначала смотрим, привязывал ли админ вручную этого плательщика к
    ученику(ам) раньше (payer_child_links) — если да, используем это без
    повторного нечёткого сравнения ФИО. Если нет — обычное сопоставление
    по имени, как раньше."""
    from app.models.models import PayerChildLink

    normalized = _normalize_name(payer_name)
    if normalized:
        result = await db.execute(
            select(PayerChildLink.child_id)
            .where(PayerChildLink.payer_name_normalized == normalized)
            .distinct()
        )
        linked_ids = [row[0] for row in result.all()]
        if linked_ids:
            return linked_ids

    single = await _find_child_by_payer_name(payer_name, db)
    return [single] if single is not None else []


async def _apply_payer_match(db: AsyncSession, receipt) -> bool:
    """Применяет сопоставление к уже сохранённому чеку (у receipt должен
    быть id). Если плательщик привязан к нескольким ученикам (брат/сестра
    и т.п.) — receipt.child_id остаётся пустым, а общая сумма семьи
    учитывается в финансовом отчёте отдельным пулом (см. finance_report),
    без деления чека на части. Возвращает True, если что-то поменялось."""
    child_ids = await _resolve_payer_children(receipt.payer_name, db)
    new_child_id = child_ids[0] if len(child_ids) == 1 else None

    changed = receipt.child_id != new_child_id
    if not changed:
        return False

    receipt.child_id = new_child_id
    return True


async def _find_child_by_payer_name(payer_name: str, db: AsyncSession) -> Optional[int]:
    """
    Safe matching:
    1. full payer name equals parent/child name, allowing both "Имя Фамилия"
       and "Фамилия Имя Отчество" order;
    2. a one-word payer name is accepted only if it points to exactly one child
       through the linked parent/child CRM names.
    """
    from sqlalchemy.orm import joinedload
    from app.models.models import User, ParentProfile, ParentChild, ChildProfile, RoleEnum

    matched_child_ids: set[int] = set()

    result = await db.execute(
        select(ChildProfile)
        .options(
            joinedload(ChildProfile.user),
            joinedload(ChildProfile.parents)
            .joinedload(ParentChild.parent)
            .joinedload(ParentProfile.user),
        )
        .join(ChildProfile.user)
        .where(User.role == RoleEnum.child, User.is_active == True)
    )

    for child in result.scalars().unique().all():
        names = [_full_name(child.user)]
        names.extend(
            _full_name(link.parent.user)
            for link in child.parents
            if link.parent and link.parent.user
        )
        if any(
            _same_person(payer_name, name) or _single_token_owner(payer_name, name)
            for name in names
        ):
            matched_child_ids.add(child.id)

    if len(matched_child_ids) == 1:
        return next(iter(matched_child_ids))
    if len(matched_child_ids) > 1:
        logger.warning("Payer %s matched multiple children %s, cannot auto-match receipt", payer_name, sorted(matched_child_ids))
    return None


async def rematch_unlinked_receipts(db: AsyncSession) -> int:
    from app.models.models import EmailReceipt

    result = await db.execute(select(EmailReceipt))
    receipts = result.scalars().all()
    matched = 0

    for receipt in receipts:
        changed = await _apply_payer_match(db, receipt)
        if changed:
            matched += 1

    if matched:
        await db.commit()

    logger.info("Email parser: rematched %d existing receipts.", matched)
    return matched


async def run_email_parse(db: AsyncSession) -> int:
    from app.models.models import EmailReceipt

    raw_receipts = _fetch_raw_receipts()
    if not raw_receipts:
        return await rematch_unlinked_receipts(db)

    saved = 0
    for r in raw_receipts:
        receipt_number = r.get("receipt_number")

        # Дедупликация по номеру чека
        if receipt_number:
            exists = await db.execute(
                select(EmailReceipt).where(EmailReceipt.receipt_number == receipt_number)
            )
        else:
            payment_date = r.get("payment_date")
            payment_date_only = payment_date.date() if hasattr(payment_date, 'date') else payment_date
            exists = await db.execute(
                select(EmailReceipt).where(
                    EmailReceipt.payer_name == r["payer_name"],
                    EmailReceipt.amount == r["amount"],
                    cast(EmailReceipt.payment_date, Date) == payment_date_only,
                )
            )

        existing_receipt = exists.scalar_one_or_none()
        if existing_receipt:
            changed = await _apply_payer_match(db, existing_receipt)
            if changed:
                saved += 1
            continue

        receipt_obj = EmailReceipt(
            receipt_number=receipt_number,
            payer_name=r["payer_name"],
            amount=r["amount"],
            payment_date=r.get("payment_date").replace(tzinfo=None) if r.get("payment_date") else None,
            raw_text=r.get("raw_text"),
        )
        db.add(receipt_obj)
        await db.flush()
        await _apply_payer_match(db, receipt_obj)
        if receipt_obj.child_id is None:
            logger.warning("Could not match payer '%s' to any child", r["payer_name"])
        saved += 1

    if saved:
        await db.commit()

    rematched = await rematch_unlinked_receipts(db)
    logger.info("Email parser: saved/rematched %d receipts.", saved + rematched)
    return saved + rematched
