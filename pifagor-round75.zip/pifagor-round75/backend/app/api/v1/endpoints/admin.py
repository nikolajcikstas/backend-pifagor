import logging
import secrets
import json
import uuid
from pathlib import Path
from typing import List, Optional
from datetime import date, timedelta

from fastapi import APIRouter, Depends, HTTPException, status, Query, UploadFile, File
from fastapi.responses import StreamingResponse
import io
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import func, cast, Date, or_
from sqlalchemy.orm import joinedload
from pydantic import BaseModel  # 🌟 Добавили для Pydantic схемы

from app.db.session import get_db
from app.core.deps import require_admin
from app.core.security import get_password_hash
from app.services.contract_parser import parse_contract_docx
from app.services.email_parser import _find_child_by_payer_name, _normalize_name
from app.services.tutor_earnings import (
    compute_earnings_bulk, compute_tutor_earnings, current_and_pending_from_history,
    get_current_and_pending_rate, load_rate_histories,
)
from app.models.models import (
    InviteCode, RoleEnum, Lesson, LessonStatus, Notification,
    ChildProfile, User, EmailReceipt, ParentProfile, ParentChild,  # 🌟 Добавили профили
    TutorProfile, TutorSubject, Subject, TutorDocument, TutorContract, Act,
    Homework, Report, Material, ParentContract, Payment, Comment, TestResult, Review,
    TutorPayout, EmailReceiptSplit, PayerChildLink, TutorRateHistory, ParentContractChild,
    QmCall, QmRegularity,
)
from app.schemas.schemas import (
    InviteCodeCreate, InviteCodeResponse,
    EmailReceiptOut, StudentFinanceRow,
    TutorProfileOut, AdminTutorUpdate,
    TutorDocumentCreate, TutorDocumentOut,
    ActOut, TutorPayoutCreate, TutorPayoutOut,
)

logger = logging.getLogger(__name__)
router = APIRouter()
MAX_INVITE_DESCRIPTION_LENGTH = 120


# Pydantic схема для ручного бинда
class BaseParentChildLink(BaseModel):
    parent_id: int
    child_id: int


class AdminStudentUpdate(BaseModel):
    lesson_price: Optional[float] = None
    grade: Optional[int] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    status: Optional[str] = None
    lessons_per_week: Optional[float] = None
    lessons_per_week_from: Optional[date] = None  # с какой даты действует новый план
    notes: Optional[str] = None
    channel: Optional[str] = None
    parent_name: Optional[str] = None
    parent_phone: Optional[str] = None
    subjects: Optional[List[str]] = None
    tutors: Optional[List[str]] = None
    contract_label: Optional[str] = None
    accounting_start_date: Optional[date] = None


class TutorWorkDocumentCreate(BaseModel):
    kind: str
    title: str
    file_url: str


def generate_random_code(prefix: str) -> str:
    return f"PIF-{prefix.upper()}-{secrets.token_hex(3).upper()}"


def _split_name(raw: str | None) -> tuple[str, str]:
    parts = (raw or "Новый ученик").strip().split()
    if len(parts) >= 2:
        return parts[1], parts[0]
    return parts[0] if parts else "Новый", "ученик"


def _clean_invite_description(description: Optional[str]) -> Optional[str]:
    if description is None:
        return None
    clean = description.strip()
    if len(clean) > MAX_INVITE_DESCRIPTION_LENGTH:
        raise HTTPException(status_code=400, detail="Описание кода слишком длинное")
    return clean or None


def _is_suspicious_invite_description(description: Optional[str]) -> bool:
    if not description:
        return False
    clean = description.strip()
    if "admin" in clean.lower() or "админ" in clean.lower():
        return True
    if len(clean) > MAX_INVITE_DESCRIPTION_LENGTH:
        return True
    allowed_punctuation = {" ", "-", "'", ".", "ё", "Ё"}
    suspicious = 0
    for ch in clean:
        code = ord(ch)
        is_latin = 0x0041 <= code <= 0x007A
        is_cyrillic = 0x0400 <= code <= 0x052F
        if not (ch.isdigit() or is_latin or is_cyrillic or ch in allowed_punctuation):
            suspicious += 1
    return suspicious > max(3, len(clean) // 5)


async def _delete_invite_codes_for_user(db: AsyncSession, user_id: int) -> int:
    result = await db.execute(select(InviteCode).where(InviteCode.used_by_user_id == user_id))
    direct_codes = result.scalars().all()
    code_ids = {code.id for code in direct_codes}
    code_ids.update(code.linked_code_id for code in direct_codes if code.linked_code_id)

    if not code_ids:
        return 0

    related = await db.execute(
        select(InviteCode).where(
            (InviteCode.id.in_(code_ids)) | (InviteCode.linked_code_id.in_(code_ids))
        )
    )
    codes = related.scalars().all()
    if not codes:
        return 0

    for code in codes:
        code.linked_code_id = None
    await db.flush()

    for code in codes:
        await db.delete(code)

    return len(codes)


async def _delete_invite_codes_for_descriptions(db: AsyncSession, descriptions: set[str]) -> int:
    clean = {item.strip() for item in descriptions if item and item.strip()}
    if not clean:
        return 0

    # только коды, не привязанные ни к какому аккаунту: раньше при удалении ученика
    # удалялись и коды его тёзок (у них то же описание «Фамилия Имя»)
    result = await db.execute(select(InviteCode).where(InviteCode.description.in_(clean),
                                                       InviteCode.used_by_user_id.is_(None)))
    direct_codes = result.scalars().all()
    code_ids = {code.id for code in direct_codes}
    code_ids.update(code.linked_code_id for code in direct_codes if code.linked_code_id)

    if not code_ids:
        return 0

    related = await db.execute(
        select(InviteCode).where(
            (InviteCode.id.in_(code_ids)) | (InviteCode.linked_code_id.in_(code_ids))
        )
    )
    codes = related.scalars().all()
    for code in codes:
        code.linked_code_id = None
    await db.flush()

    for code in codes:
        await db.delete(code)

    return len(codes)


@router.post("/invite-codes", response_model=List[InviteCodeResponse], dependencies=[Depends(require_admin)])
async def create_invite_codes(payload: InviteCodeCreate, db: AsyncSession = Depends(get_db)):
    role_str = str(payload.role).strip().lower()
    description = _clean_invite_description(payload.description)

    if role_str in ["pair", "student_parent"]:
        child_code = generate_random_code("CHD")
        child_invite = InviteCode(role=RoleEnum.child, code=child_code, description=description)
        db.add(child_invite)
        await db.flush()

        parent_code = generate_random_code("PRN")
        parent_invite = InviteCode(
            role=RoleEnum.parent,
            code=parent_code,
            description=description,
            linked_code_id=child_invite.id
        )
        db.add(parent_invite)

        first_name, last_name = _split_name(description)
        from app.core.security import ahash_password
        placeholder_password = await ahash_password(secrets.token_urlsafe(24))

        child_user = User(
            email=f"placeholder-child-{child_code.lower()}@pifagor.local",
            hashed_password=placeholder_password,
            first_name=first_name,
            last_name=last_name,
            middle_name="",
            phone=None,
            role=RoleEnum.child,
            is_active=True,
        )
        parent_user = User(
            email=f"placeholder-parent-{parent_code.lower()}@pifagor.local",
            hashed_password=placeholder_password,
            first_name="Родитель",
            last_name=f"{last_name} {first_name}".strip(),
            middle_name="",
            phone=None,
            role=RoleEnum.parent,
            is_active=True,
        )
        db.add_all([child_user, parent_user])
        await db.flush()

        child_profile = ChildProfile(user_id=child_user.id, crm_status="Пробное")
        parent_profile = ParentProfile(user_id=parent_user.id)
        db.add_all([child_profile, parent_profile])
        await db.flush()
        db.add(ParentChild(parent_id=parent_profile.id, child_id=child_profile.id))

        child_invite.used_by_user_id = child_user.id
        parent_invite.used_by_user_id = parent_user.id

        await db.commit()
        return [child_invite, parent_invite]

    if role_str == "tutor":
        code_str = generate_random_code("TUT")
        invite = InviteCode(role=RoleEnum.tutor, code=code_str, description=description)
        db.add(invite)
        await db.commit()
        return [invite]

    raise HTTPException(status_code=400, detail=f"Неверная роль для генерации кода: {payload.role}")


def _real_phone(p: Optional[str]) -> bool:
    from app.services.phone_repair import real_phone
    return real_phone(p)


def _is_placeholder_email(email: Optional[str]) -> bool:
    return not email or email.strip().lower().endswith("@pifagor.local")


async def _ensure_student_codes(db: AsyncSession) -> int:
    """У каждого ученика из CRM должна быть пара кодов «ученик + родитель».
    Если кодов нет (удалились вместе с кодами тёзки, были созданы до привязки
    кодов к аккаунтам и т.п.) — создаём пару и привязываем к существующим
    аккаунтам ученика и родителя. Код уже зарегистрированного аккаунта
    сразу помечается использованным, чтобы по нему нельзя было перезаписать
    чужой аккаунт."""
    from app.core.security import ahash_password
    kids = (await db.execute(
        select(ChildProfile.id, ChildProfile.user_id, User.first_name, User.last_name, User.email)
        .join(User, User.id == ChildProfile.user_id)
    )).all()
    bound = set((await db.execute(
        select(InviteCode.used_by_user_id).where(InviteCode.role == RoleEnum.child, InviteCode.used_by_user_id.isnot(None))
    )).scalars().all())
    missing = [k for k in kids if k[1] not in bound]
    if not missing:
        return 0
    parents_of: dict[int, int] = {}
    for cid, puid in (await db.execute(
        select(ParentChild.child_id, ParentProfile.user_id).join(ParentProfile, ParentProfile.id == ParentChild.parent_id)
        .where(ParentChild.child_id.in_([k[0] for k in missing])).order_by(ParentChild.id)
    )).all():
        parents_of.setdefault(cid, puid)
    parent_emails = dict((await db.execute(
        select(User.id, User.email).where(User.id.in_(list(parents_of.values()) or [-1]))
    )).all())
    placeholder_pw = None
    for cid, uid, first, last, email in missing:
        name = f"{last or ''} {first or ''}".strip() or None
        child_code = InviteCode(role=RoleEnum.child, code=generate_random_code("CHD"), description=name,
                                used_by_user_id=uid, is_used=not _is_placeholder_email(email))
        db.add(child_code)
        await db.flush()
        puid = parents_of.get(cid)
        if puid is None:
            if placeholder_pw is None:
                placeholder_pw = await ahash_password(secrets.token_urlsafe(24))
            pcode = generate_random_code("PRN")
            pu = User(email=f"placeholder-parent-{pcode.lower()}@pifagor.local", hashed_password=placeholder_pw,
                      first_name="Родитель", last_name=name or "ученика", middle_name="", phone=None,
                      role=RoleEnum.parent, is_active=True)
            db.add(pu)
            await db.flush()
            pp = ParentProfile(user_id=pu.id)
            db.add(pp)
            await db.flush()
            db.add(ParentChild(parent_id=pp.id, child_id=cid))
            db.add(InviteCode(role=RoleEnum.parent, code=pcode, description=name, linked_code_id=child_code.id,
                              used_by_user_id=pu.id, is_used=False))
        else:
            db.add(InviteCode(role=RoleEnum.parent, code=generate_random_code("PRN"), description=name,
                              linked_code_id=child_code.id, used_by_user_id=puid,
                              is_used=not _is_placeholder_email(parent_emails.get(puid))))
    await db.commit()
    logger.warning("Invite codes restored for %s students", len(missing))
    return len(missing)


@router.get("/invite-codes", response_model=List[InviteCodeResponse], dependencies=[Depends(require_admin)])
async def list_invite_codes(db: AsyncSession = Depends(get_db)):
    try:
        await _ensure_student_codes(db)
    except Exception:  # восстановление — дополнение; список всё равно показываем
        logger.exception("restore invite codes failed")
        await db.rollback()
    codes = (await db.execute(select(InviteCode).order_by(InviteCode.created_at.desc()))).scalars().all()
    by_id = {c.id: c for c in codes}
    users = {uid: (role, first, last) for uid, role, first, last in (await db.execute(
        select(User.id, User.role, User.first_name, User.last_name)
        .where(User.id.in_([c.used_by_user_id for c in codes if c.used_by_user_id] or [-1]))
    )).all()}
    child_user_rows = (await db.execute(
        select(User.first_name, User.last_name).join(ChildProfile, ChildProfile.user_id == User.id)
    )).all()
    active_child_names = {f"{last} {first}".strip() for first, last in child_user_rows if first or last} | \
        {f"{first} {last}".strip() for first, last in child_user_rows if first or last}

    def child_name(code) -> Optional[str]:
        u = users.get(code.used_by_user_id) if code.used_by_user_id else None
        return f"{u[2] or ''} {u[1] or ''}".strip() if u and u[0] == RoleEnum.child else None

    visible = []
    for code in codes:
        description = (code.description or "").strip()
        if _is_suspicious_invite_description(description):
            continue
        if code.role in (RoleEnum.child, RoleEnum.parent):
            if code.used_by_user_id:
                # код привязан к аккаунту: показываем, пока аккаунт есть; имя — текущее имя ученика
                # (раньше код пропадал, если ученик при регистрации написал имя иначе или его переименовали в CRM)
                if code.used_by_user_id not in users:
                    continue
                if code.role == RoleEnum.child:
                    description = child_name(code) or description
                else:
                    partner = by_id.get(code.linked_code_id) if code.linked_code_id else None
                    description = (child_name(partner) if partner else None) or description
            elif description and description not in active_child_names:
                continue
        visible.append(InviteCodeResponse(
            id=code.id, code=code.code, role=code.role, description=description or None,
            is_used=bool(code.is_used), linked_code_id=code.linked_code_id, created_at=code.created_at,
        ))
    return visible



@router.delete("/invite-codes", dependencies=[Depends(require_admin)])
async def clear_invite_codes(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(InviteCode))
    codes = result.scalars().all()

    for code in codes:
        code.linked_code_id = None
    await db.flush()

    for code in codes:
        await db.delete(code)

    await db.commit()
    return {"deleted": len(codes)}


# ─── Email Receipts ────────────────────────────────────────────────────────────

@router.get("/receipts", response_model=List[EmailReceiptOut], dependencies=[Depends(require_admin)])
async def list_receipts(db: AsyncSession = Depends(get_db)):
    """List all parsed email receipts (admin only)."""
    result = await db.execute(
        select(EmailReceipt)
        .options(joinedload(EmailReceipt.child).joinedload(ChildProfile.user))
        .order_by(EmailReceipt.payment_date.desc())
    )
    receipts = result.scalars().unique().all()

    # Плательщики, привязанные сразу к нескольким ученикам (семьи) —
    # чтобы показать их имена вместо «не сопоставлен».
    links_res = await db.execute(
        select(PayerChildLink).options(joinedload(PayerChildLink.child).joinedload(ChildProfile.user))
    )
    group_names: dict[str, list] = {}
    group_counts: dict[str, int] = {}
    for link in links_res.scalars().unique().all():
        group_counts[link.payer_name_normalized] = group_counts.get(link.payer_name_normalized, 0) + 1
        if link.child and link.child.user:
            u = link.child.user
            group_names.setdefault(link.payer_name_normalized, []).append(
                {"child_id": link.child_id, "name": f"{u.last_name} {u.first_name}".strip(), "amount": None}
            )
    families = {key for key, count in group_counts.items() if count > 1}

    output = []
    for r in receipts:
        student_name = None
        if r.child and r.child.user:
            u = r.child.user
            student_name = f"{u.last_name} {u.first_name}".strip()

        norm = _normalize_name(r.payer_name)
        split_children = group_names.get(norm, []) if norm in families else []

        output.append(EmailReceiptOut(
            id=r.id,
            receipt_number=r.receipt_number,
            payer_name=r.payer_name,
            amount=r.amount,
            payment_date=r.payment_date,
            child_id=r.child_id,
            student_name=student_name,
            is_unmatched=r.child_id is None and not split_children,
            split_children=split_children,
            created_at=r.created_at,
        ))
    return output


class ReceiptAssignChildren(BaseModel):
    child_ids: List[int]


@router.post("/receipts/{receipt_id}/assign-children", dependencies=[Depends(require_admin)])
async def assign_receipt_children(
    receipt_id: int, payload: ReceiptAssignChildren, db: AsyncSession = Depends(get_db)
):
    """Вручную привязать чек к одному или нескольким ученикам (например,
    брат и сестра, оплаченные одним платежом — сумма поделится поровну).
    Заодно запоминает эту привязку для плательщика — чтобы в будущем чеки
    от него сопоставлялись автоматически, без повторной ручной работы."""
    from app.services.email_parser import _apply_payer_match, _normalize_name
    from app.models.models import PayerChildLink

    if not payload.child_ids:
        raise HTTPException(status_code=400, detail="Нужно указать хотя бы одного ученика")

    result = await db.execute(select(EmailReceipt).where(EmailReceipt.id == receipt_id))
    receipt = result.scalar_one_or_none()
    if not receipt:
        raise HTTPException(status_code=404, detail="Чек не найден")

    children_res = await db.execute(
        select(ChildProfile.id).where(ChildProfile.id.in_(payload.child_ids))
    )
    valid_ids = {row[0] for row in children_res.all()}
    if valid_ids != set(payload.child_ids):
        raise HTTPException(status_code=404, detail="Один или несколько учеников не найдены")

    normalized = _normalize_name(receipt.payer_name)
    existing_links_res = await db.execute(
        select(PayerChildLink.child_id).where(PayerChildLink.payer_name_normalized == normalized)
    )
    existing_link_ids = {row[0] for row in existing_links_res.all()}
    for cid in payload.child_ids:
        if cid not in existing_link_ids:
            db.add(PayerChildLink(payer_name_normalized=normalized, child_id=cid))
    await db.flush()

    # Применяем эту привязку не только к текущему чеку, но и ко всем другим
    # чекам от того же плательщика (включая более старые, уже лежавшие
    # непривязанными) — чтобы одна ручная привязка закрывала всю историю.
    all_receipts_res = await db.execute(select(EmailReceipt))
    for other_receipt in all_receipts_res.scalars().all():
        if _normalize_name(other_receipt.payer_name) == normalized:
            await _apply_payer_match(db, other_receipt)
    await db.commit()

    result = await db.execute(
        select(EmailReceipt)
        .options(joinedload(EmailReceipt.child).joinedload(ChildProfile.user))
        .where(EmailReceipt.id == receipt_id)
    )
    r = result.unique().scalar_one()
    student_name = f"{r.child.user.last_name} {r.child.user.first_name}".strip() if r.child and r.child.user else None

    group_names_res = await db.execute(
        select(PayerChildLink).options(joinedload(PayerChildLink.child).joinedload(ChildProfile.user))
        .where(PayerChildLink.payer_name_normalized == normalized)
    )
    group_links = group_names_res.unique().scalars().all()
    split_children = [
        {"child_id": l.child_id, "name": f"{l.child.user.last_name} {l.child.user.first_name}".strip(), "amount": None}
        for l in group_links if l.child and l.child.user
    ] if len(group_links) > 1 else []

    return EmailReceiptOut(
        id=r.id, receipt_number=r.receipt_number, payer_name=r.payer_name, amount=r.amount,
        payment_date=r.payment_date, child_id=r.child_id, student_name=student_name,
        is_unmatched=r.child_id is None and not split_children,
        split_children=split_children, created_at=r.created_at,
    )


@router.post("/receipts/parse-emails", dependencies=[Depends(require_admin)])
async def trigger_email_parsing(db: AsyncSession = Depends(get_db)):
    """Manually trigger email inbox parsing for new EasyPay receipts."""
    from app.services.email_parser import run_email_parse
    count = await run_email_parse(db)
    return {"new_receipts": count, "message": f"Обработано новых чеков: {count}"}


# ─── Finance Report ────────────────────────────────────────────────────────────

@router.post("/receipts/rematch", dependencies=[Depends(require_admin)])
async def rematch_receipts(db: AsyncSession = Depends(get_db)):
    from app.services.email_parser import rematch_unlinked_receipts
    count = await rematch_unlinked_receipts(db)
    return {"matched_receipts": count}


@router.get("/finance-report", response_model=List[StudentFinanceRow], dependencies=[Depends(require_admin)])
async def finance_report(
        week_start: Optional[date] = Query(None),
        db: AsyncSession = Depends(get_db),
):
    """Finance report per student. If week_start is provided, limit it to that week."""
    from app.services.finance_report import compute_finance_rows
    return await compute_finance_rows(db, week_start=week_start)


@router.patch("/students/{user_id}", dependencies=[Depends(require_admin)])
async def update_admin_student(
    user_id: int,
    payload: AdminStudentUpdate,
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(require_admin),
):
    result = await db.execute(
        select(User)
        .options(
            joinedload(User.child_profile)
            .joinedload(ChildProfile.parents)
            .joinedload(ParentChild.parent)
            .joinedload(ParentProfile.user)
        )
        .where(User.id == user_id, User.role == RoleEnum.child)
    )
    student = result.scalars().unique().one_or_none()
    if not student or not student.child_profile:
        raise HTTPException(status_code=404, detail="Student not found")

    def _names_state():
        """ФИО ученика и родителя — по ним сопоставляются чеки об оплате."""
        p = next((l.parent.user for l in student.child_profile.parents if l.parent and l.parent.user), None)
        return (student.first_name, student.last_name,
                (p.last_name, p.first_name, p.phone) if p else None)

    names_before = _names_state()

    if payload.lesson_price is not None:
        if payload.lesson_price <= 0:
            raise HTTPException(status_code=400, detail="Lesson price must be greater than zero")
        if payload.lesson_price != student.child_profile.lesson_price:
            from app.models.models import StudentPriceHistory
            from app.services.pricing import set_price_from, minsk_today
            has_hist = (await db.execute(
                select(StudentPriceHistory.id).where(StudentPriceHistory.child_id == student.child_profile.id).limit(1)
            )).first() is not None
            if has_hist:
                # у ученика уже есть история цен — новая цена действует с сегодня,
                # прошлые занятия остаются по прежней цене
                await set_price_from(db, student.child_profile, payload.lesson_price, minsk_today(),
                                     reason="Изменено в CRM")
            student.child_profile.lesson_price = payload.lesson_price
    if payload.grade is not None:
        student.child_profile.grade = payload.grade
    if payload.first_name is not None:
        student.first_name = payload.first_name.strip()
    if payload.last_name is not None:
        student.last_name = payload.last_name.strip()
    if payload.phone is not None:
        student.phone = payload.phone.strip() or None
    if payload.status is not None:
        student.child_profile.crm_status = payload.status.strip() or "Пробное"
    if payload.lessons_per_week is not None:
        lpw = round(float(payload.lessons_per_week), 2)
        if lpw < 0 or lpw > 21:
            raise HTTPException(status_code=400, detail="Занятий в неделю: от 0 до 21 (можно дробное, например 0,5 — раз в 2 недели)")
        if lpw != student.child_profile.lessons_per_week:
            student.child_profile.lessons_per_week = lpw
            from app.api.v1.endpoints.analytics import apply_plan_change
            await apply_plan_change(db, student.child_profile.id, lpw, payload.lessons_per_week_from,
                                    who=f"{current_admin.last_name or ''} {current_admin.first_name or ''}".strip() or current_admin.email)
    if payload.notes is not None:
        student.child_profile.notes = payload.notes.strip() or None
    if payload.channel is not None:
        student.child_profile.channel = payload.channel.strip() or None
    if payload.subjects is not None:
        student.child_profile.subjects_text = ", ".join(s.strip() for s in payload.subjects if s.strip()) or None
    if payload.tutors is not None:
        student.child_profile.tutors_text = ", ".join(t.strip() for t in payload.tutors if t.strip()) or None
    if payload.contract_label is not None:
        student.child_profile.contract_label = payload.contract_label.strip() or None
    if payload.accounting_start_date is not None:
        student.child_profile.accounting_start_date = payload.accounting_start_date

    if payload.status is not None and payload.status.strip() == "Отказ":
        this_child_id = student.child_profile.id
        contracts_res = await db.execute(
            select(ParentContract)
            .options(joinedload(ParentContract.extra_children))
            .where(
                or_(
                    ParentContract.child_id == this_child_id,
                    ParentContract.id.in_(
                        select(ParentContractChild.contract_id).where(
                            ParentContractChild.child_id == this_child_id
                        )
                    ),
                )
            )
        )
        for contract in contracts_res.unique().scalars().all():
            other_child_ids = [
                link.child_id for link in contract.extra_children
                if link.child_id != this_child_id
            ]
            if contract.child_id is not None and contract.child_id != this_child_id:
                other_child_ids.insert(0, contract.child_id)
            # убираем дубликаты, сохраняя порядок
            seen = set()
            other_child_ids = [cid for cid in other_child_ids if not (cid in seen or seen.add(cid))]

            if not other_child_ids:
                # этот ученик был единственным привязанным — удаляем весь договор
                await db.execute(
                    ParentContractChild.__table__.delete().where(
                        ParentContractChild.contract_id == contract.id
                    )
                )
                await db.delete(contract)
            else:
                # к договору привязаны другие ученики — отвязываем только этого,
                # остальные остаются со статусом "Действующий"
                await db.execute(
                    ParentContractChild.__table__.delete().where(
                        ParentContractChild.contract_id == contract.id,
                        ParentContractChild.child_id == this_child_id,
                    )
                )
                if contract.child_id == this_child_id:
                    new_primary = other_child_ids[0]
                    contract.child_id = new_primary
                    await db.execute(
                        ParentContractChild.__table__.delete().where(
                            ParentContractChild.contract_id == contract.id,
                            ParentContractChild.child_id == new_primary,
                        )
                    )


    # правим того родителя, чей телефон показан в CRM (первый с настоящим номером)
    parent_users = [link.parent.user for link in student.child_profile.parents if link.parent and link.parent.user]
    parent_user = next((u for u in parent_users if _real_phone(u.phone)), parent_users[0] if parent_users else None)
    if parent_user:
        if payload.parent_name is not None:
            parts = payload.parent_name.strip().split()
            parent_user.last_name = parts[0] if parts else ""
            parent_user.first_name = " ".join(parts[1:]) if len(parts) > 1 else ""
        if payload.parent_phone is not None:
            parent_user.phone = payload.parent_phone.strip() or None

    # Чеки пересопоставляются, только если реально поменялись ФИО/телефон
    # (форма CRM присылает все поля при каждом сохранении).
    should_rematch_receipts = _names_state() != names_before
    # Реферальные ссылки: «Пригласил: …» в комментарии или заявка с этим телефоном
    from app.services.referrals import process_child_referral
    referral_msg = await process_child_referral(
        db, student.child_profile, student,
        [l.parent.user for l in student.child_profile.parents if l.parent and l.parent.user],
    )
    await db.commit()
    if should_rematch_receipts:
        from app.services.email_parser import rematch_unlinked_receipts

        await rematch_unlinked_receipts(db)
    return {
        "ok": True,
        "lesson_price": student.child_profile.lesson_price,
        "grade": student.child_profile.grade,
        "first_name": student.first_name,
        "last_name": student.last_name,
        "phone": student.phone,
        "status": student.child_profile.crm_status,
        "lessons_per_week": student.child_profile.lessons_per_week,
        "notes": student.child_profile.notes,
        "channel": student.child_profile.channel,
        "subjects": [s.strip() for s in (student.child_profile.subjects_text or "").split(",") if s.strip()],
        "tutors": [t.strip() for t in (student.child_profile.tutors_text or "").split(",") if t.strip()],
        "contract_label": student.child_profile.contract_label,
        "accounting_start_date": (
            student.child_profile.accounting_start_date.isoformat()
            if student.child_profile.accounting_start_date else None
        ),
        "parent_name": f"{parent_user.last_name} {parent_user.first_name}".strip() if parent_user else "",
        "parent_phone": parent_user.phone if parent_user else "",
        "referral_msg": referral_msg,
        "ref_code": student.child_profile.ref_code,
    }


@router.get("/students-dashboard", dependencies=[Depends(require_admin)])
async def students_dashboard(db: AsyncSession = Depends(get_db)):
    # Раньше здесь подгружались ВСЕ занятия каждого ученика (joinedload даёт
    # огромное декартово произведение строк), а наличие договора проверялось
    # отдельным запросом на каждого ученика — при ~130 учениках это ~130 лишних
    # обращений к базе и несколько секунд ожидания. Теперь всё собирается
    # тремя запросами независимо от числа учеников; результат тот же.
    from sqlalchemy.orm import selectinload

    result = await db.execute(
        select(ChildProfile)
        .options(
            joinedload(ChildProfile.user),
            selectinload(ChildProfile.parents).joinedload(ParentChild.parent).joinedload(ParentProfile.user),
        )
    )
    children = result.scalars().unique().all()
    child_ids = [c.id for c in children]

    lesson_subjects_map: dict[int, set] = {}
    lesson_tutors_map: dict[int, set] = {}
    if child_ids:
        TutorUser = User
        lesson_rows = await db.execute(
            select(Lesson.child_id, Subject.name, TutorUser.last_name, TutorUser.first_name)
            .select_from(Lesson)
            .outerjoin(Subject, Subject.id == Lesson.subject_id)
            .outerjoin(TutorProfile, TutorProfile.id == Lesson.tutor_id)
            .outerjoin(TutorUser, TutorUser.id == TutorProfile.user_id)
            .where(Lesson.child_id.in_(child_ids))
            .distinct()
        )
        for cid, subject_name, t_last, t_first in lesson_rows.all():
            if subject_name:
                lesson_subjects_map.setdefault(cid, set()).add(subject_name)
            if t_last is not None or t_first is not None:
                lesson_tutors_map.setdefault(cid, set()).add(f"{t_last} {t_first}".strip())

    # реферальные ссылки: коды для клиентов без кода, статистика и скидки
    from app.services.referrals import ensure_codes, referral_stats
    from app.services.pricing import discount_state, discount_offer
    await ensure_codes(db)  # те же объекты в сессии — коды сразу видны в children
    ref_stats = await referral_stats(db)
    disc = await discount_state(db, child_ids)

    contract_rows = await db.execute(
        select(ParentContract.child_id, ParentContractChild.child_id)
        .select_from(ParentContract)
        .outerjoin(ParentContractChild, ParentContractChild.contract_id == ParentContract.id)
        .where(ParentContract.match_status == "matched")
    )
    children_with_contract: set[int] = set()
    for primary_child_id, extra_child_id in contract_rows.all():
        if primary_child_id is not None:
            children_with_contract.add(primary_child_id)
        if extra_child_id is not None:
            children_with_contract.add(extra_child_id)

    rows = []
    for child in children:
        user = child.user
        if not user:
            continue
        parents = [link.parent.user for link in child.parents if link.parent and link.parent.user]
        lesson_subjects = sorted(lesson_subjects_map.get(child.id, set()))
        lesson_tutors = sorted(lesson_tutors_map.get(child.id, set()))
        subjects = [s.strip() for s in (child.subjects_text or "").split(",") if s.strip()] or lesson_subjects
        tutors = [t.strip() for t in (child.tutors_text or "").split(",") if t.strip()] or lesson_tutors
        has_contract = child.id in children_with_contract
        parent_names = [f"{p.last_name} {p.first_name}".strip() for p in parents]
        # заглушку +375000000000 (её подставляла регистрация) не показываем
        parent_phones = [p.phone for p in parents if _real_phone(p.phone)]
        # тот же родитель, которого правит сохранение карточки (первый с настоящим номером)
        main_parent = next((p for p in parents if _real_phone(p.phone)), parents[0] if parents else None)
        rows.append({
            "child_id": child.id,
            "user_id": user.id,
            "status": child.crm_status if user.is_active else "Не занимаются",
            "lesson_price": child.lesson_price,
            "student_name": f"{user.last_name} {user.first_name}".strip(),
            "grade": child.grade,
            "lessons_per_week": child.lessons_per_week,
            "subjects": subjects,
            "tutors": tutors,
            "has_contract": has_contract,
            "contract_label": (
                "Расторгнут" if child.contract_label == "Расторгнут"
                else ("Действующий" if has_contract else "Ожидает")
            ),
            "notes": child.notes or "",
            "student_phone": user.phone,
            "parent_names": parent_names,
            "parent_phones": parent_phones,
            "parent_name": (f"{main_parent.last_name} {main_parent.first_name}".strip() if main_parent else ""),
            "parent_phone": parent_phones[0] if parent_phones else "",
            "channel": child.channel or "",
            "accounting_start_date": (
                child.accounting_start_date.isoformat() if child.accounting_start_date else None
            ),
            "ref_code": child.ref_code,
            "ref_sent_at": child.ref_sent_at.isoformat() + "Z" if child.ref_sent_at else None,
            "ref_leads": ref_stats.get(child.id, {}).get("leads", 0),
            "ref_leads_total": ref_stats.get(child.id, {}).get("leads_total", 0),
            "ref_clients": ref_stats.get(child.id, {}).get("clients", 0),
            "discount_pct": disc.get(child.id, {}).get("applied", 0),
            "discount_offer": discount_offer(
                child.lesson_price, disc.get(child.id, {}).get("applied", 0), disc.get(child.id, {}).get("base"),
                ref_stats.get(child.id, {}).get("leads", 0)),
        })
    return rows


async def _mark_child_as_active_client(db: AsyncSession, child_id: int) -> None:
    """При успешной привязке договора переводим ученика в CRM-статус «Клиент»
    (это и есть статус подтверждённого активного ученика — отдельного
    статуса «Действующий» в CRM не предусмотрено)."""
    child_res = await db.execute(select(ChildProfile).where(ChildProfile.id == child_id))
    child = child_res.scalar_one_or_none()
    if child and child.crm_status != "Клиент":
        child.crm_status = "Клиент"


def _serialize_contract(contract: ParentContract) -> dict:
    parent_user = contract.parent.user if contract.parent else None
    child_user = contract.child.user if contract.child else None
    extra = [ec for ec in (contract.extra_children or []) if ec.child and ec.child.user]
    if extra:
        student_name = ", ".join(
            f"{ec.child.user.last_name} {ec.child.user.first_name}".strip() for ec in extra
        )
        child_ids = [ec.child_id for ec in extra]
    else:
        student_name = f"{child_user.last_name} {child_user.first_name}".strip() if child_user else ""
        child_ids = [contract.child_id] if contract.child_id else []
    return {
        "id": f"parent-{contract.id}",
        "db_id": contract.id,
        "number": contract.contract_number or f"P-{contract.id:04d}",
        "contract_number": contract.contract_number or "",
        "type": "Родитель",
        "status": "Действующий" if contract.is_signed else "Ожидает подписи",
        "match_status": contract.match_status,
        "needs_review": contract.needs_review,
        "start_date": contract.start_date.isoformat() if contract.start_date else None,
        "end_date": contract.end_date.isoformat() if contract.end_date else None,
        "parent_full_name": contract.parent_full_name or (
            f"{parent_user.last_name} {parent_user.first_name}".strip() if parent_user else ""
        ),
        "parent_phone": contract.parent_phone or (parent_user.phone if parent_user else ""),
        "city": contract.city or "",
        "street": contract.street or "",
        "house": contract.house or "",
        "email": contract.parent_email or (parent_user.email if parent_user else ""),
        "recommendation": contract.recommendation,
        "recommendation_as_of": contract.recommendation_as_of.isoformat() if contract.recommendation_as_of else None,
        "student_name": student_name,
        "child_id": contract.child_id,
        "child_ids": child_ids,
        "total_amount": contract.total_amount,
    }


async def _compute_recommendation(
    db: AsyncSession, contract: ParentContract, as_of: date
) -> tuple[Optional[str], Optional[str]]:
    """Сравнивает, сколько занятий должно было пройти согласно графику
    платежей на дату as_of, с тем, сколько реально проведено.
    Возвращает (рекомендация, причина_пропуска) — ровно одно из двух не None."""
    if not contract.child_id:
        return None, "Договор ещё не привязан к ученику"

    if contract.payment_mode == "per_lesson":
        return "После каждого занятия", None
    if contract.payment_mode == "monthly":
        return "Оплата ежемесячно (фиксированного графика по занятиям нет)", None

    payments = json.loads(contract.payments_json) if contract.payments_json else []
    if not payments:
        return None, "Не удалось распознать график платежей в тексте договора — проверьте вручную"

    due_payments = [
        p for p in payments
        if date.fromisoformat(p["due_date"]) <= as_of
    ]
    if not due_payments:
        return None, "На эту дату в договоре ещё нет ни одного срока платежа — договор не исследуется"

    total_due = round(sum(p["amount"] for p in due_payments), 2)

    child_res = await db.execute(select(ChildProfile).where(ChildProfile.id == contract.child_id))
    child = child_res.scalar_one_or_none()
    if not child or not child.lesson_price:
        return None, "У ученика не указана стоимость занятия — расчёт невозможен"

    a = int(total_due // child.lesson_price)

    count_res = await db.execute(
        select(func.count(Lesson.id)).where(
            Lesson.child_id == contract.child_id,
            Lesson.status == LessonStatus.completed,
            Lesson.date <= as_of,
        )
    )
    b = count_res.scalar() or 0

    if a > b:
        return f"Отработать {a - b} занятий (на {as_of.isoformat()})", None
    if b > a:
        return f"Проведено на {b - a} занятий больше (на {as_of.isoformat()})", None
    return f"Соответствует графику оплат (на {as_of.isoformat()})", None


async def _process_one_contract_file(
    filename: str, contents: bytes, db: AsyncSession
) -> dict:
    """Общая логика обработки одного файла договора — используется и при
    одиночной, и при массовой загрузке. Бросает ValueError с понятным
    сообщением при любой проблеме, чтобы массовая загрузка могла просто
    пропустить этот файл и продолжить со следующим."""
    ext = Path(filename or "").suffix.lower()
    if ext != ".docx":
        raise ValueError("поддерживаются только файлы .docx")
    if len(contents) > 15 * 1024 * 1024:
        raise ValueError("файл слишком большой, максимум 15 МБ")

    # Файл договора больше нигде не сохраняется (ни на диске, ни в БД) —
    # только данные, распознанные из его текста. Разбираем прямо из памяти,
    # без записи на диск.
    try:
        parsed = parse_contract_docx(io.BytesIO(contents))
    except Exception as e:
        raise ValueError(f"не удалось разобрать договор: {e}")

    child_id = None
    parent_id = None
    match_status = "unmatched"
    match_name = parsed.get("client_name_header") or parsed.get("parent_full_name")
    if match_name:
        child_id = await _find_child_by_payer_name(match_name, db)
        if child_id:
            match_status = "matched"
            parent_link_res = await db.execute(
                select(ParentChild).where(ParentChild.child_id == child_id)
            )
            parent_link = parent_link_res.scalars().first()
            if parent_link:
                parent_id = parent_link.parent_id
            await _mark_child_as_active_client(db, child_id)
        else:
            match_status = "ambiguous_or_unmatched"

    warnings = list(parsed.get("parse_warnings") or [])
    if match_status != "matched":
        warnings.append("Не удалось однозначно привязать договор к ученику — выберите вручную")

    contract = ParentContract(
        parent_id=parent_id,
        child_id=child_id,
        # Сам файл больше не хранится — сохраняем только его исходное имя
        # (для истории/логов), колонка file_url в схеме обязательная.
        file_url=filename or "contract.docx",
        is_signed=True,
        contract_number=parsed.get("contract_number"),
        client_name_raw=match_name,
        start_date=parsed.get("start_date"),
        end_date=parsed.get("end_date"),
        total_amount=parsed.get("total_amount"),
        parent_full_name=parsed.get("parent_full_name"),
        parent_phone=parsed.get("parent_phone"),
        parent_email=parsed.get("parent_email"),
        city=parsed.get("city"),
        street=parsed.get("street"),
        house=parsed.get("house"),
        payments_json=json.dumps(parsed.get("payments") or []),
        match_status=match_status,
        needs_review=bool(warnings),
        payment_mode=parsed.get("payment_mode") or "unknown",
    )
    db.add(contract)
    await db.flush()

    result = await db.execute(
        select(ParentContract).options(
            joinedload(ParentContract.parent).joinedload(ParentProfile.user),
            joinedload(ParentContract.child).joinedload(ChildProfile.user),
            joinedload(ParentContract.extra_children).joinedload(ParentContractChild.child).joinedload(ChildProfile.user),
        ).where(ParentContract.id == contract.id)
    )
    row = _serialize_contract(result.unique().scalar_one())
    row["parse_warnings"] = warnings
    return row


@router.post("/contracts/upload", dependencies=[Depends(require_admin)])
async def upload_contract(file: UploadFile = File(...), db: AsyncSession = Depends(get_db)):
    """Загрузить уже подписанный договор (.docx) — распознаётся автоматически:
    ФИО заказчика, даты, сумма, график платежей, контакты. Договор пытается
    сам привязаться к ученику по совпадению ФИО (та же логика, что и для
    чеков об оплате)."""
    contents = await file.read()
    try:
        row = await _process_one_contract_file(file.filename or "", contents, db)
    except Exception as e:
        await db.rollback()
        raise HTTPException(status_code=400, detail=str(e))
    await db.commit()
    return row


@router.post("/contracts/upload-bulk", dependencies=[Depends(require_admin)])
async def upload_contracts_bulk(
    files: List[UploadFile] = File(...), db: AsyncSession = Depends(get_db)
):
    """Загрузить несколько договоров разом. Файлы, которые не получилось
    разобрать, пропускаются — остальные загружаются как обычно."""
    created = []
    failed = []
    for f in files:
        contents = await f.read()
        try:
            row = await _process_one_contract_file(f.filename or "", contents, db)
            created.append(row)
        except Exception as e:
            await db.rollback()
            failed.append({"filename": f.filename or "", "reason": str(e)})
    await db.commit()
    return {"created": created, "failed": failed}


@router.post("/contracts/manual", dependencies=[Depends(require_admin)])
async def create_manual_contract(db: AsyncSession = Depends(get_db)):
    """Создать пустой договор для ручного заполнения — для случаев, когда
    файл .docx не удаётся разобрать автоматически. Дальше все поля
    заполняются прямо в таблице, через тот же 'Сохранить правки', что и
    у обычных распознанных договоров."""
    contract = ParentContract(
        file_url="",
        is_signed=False,
        match_status="unmatched",
        needs_review=True,
        payment_mode="unknown",
    )
    db.add(contract)
    await db.commit()
    await db.refresh(contract)
    return _serialize_contract(contract)


@router.delete("/contracts/{contract_id}", dependencies=[Depends(require_admin)])
async def delete_contract(contract_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(ParentContract).where(ParentContract.id == contract_id))
    contract = result.scalar_one_or_none()
    if not contract:
        raise HTTPException(status_code=404, detail="Договор не найден")
    await db.delete(contract)
    await db.commit()
    return {"deleted": True}


class ContractFieldsUpdate(BaseModel):
    contract_number: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    total_amount: Optional[float] = None
    parent_full_name: Optional[str] = None
    parent_phone: Optional[str] = None
    parent_email: Optional[str] = None
    city: Optional[str] = None
    street: Optional[str] = None
    house: Optional[str] = None


@router.patch("/contracts/{contract_id}", dependencies=[Depends(require_admin)])
async def update_contract_fields(
    contract_id: int, payload: ContractFieldsUpdate, db: AsyncSession = Depends(get_db)
):
    """Ручная правка полей договора — как для полей, которые распознал
    парсер и ошибся, так и для договора, заполненного полностью вручную
    (когда файл вообще не удалось разобрать)."""
    result = await db.execute(select(ParentContract).where(ParentContract.id == contract_id))
    contract = result.scalar_one_or_none()
    if not contract:
        raise HTTPException(status_code=404, detail="Договор не найден")

    updates = payload.model_dump(exclude_unset=True)
    for field, value in updates.items():
        setattr(contract, field, value)

    # Если указали ФИО родителя, а договор ещё ни к кому не привязан —
    # пробуем сопоставить с учеником автоматически (та же логика, что и
    # для чеков об оплате). Не получится — можно привязать вручную, как обычно.
    if "parent_full_name" in updates and updates["parent_full_name"] and contract.child_id is None:
        child_id = await _find_child_by_payer_name(updates["parent_full_name"], db)
        if child_id:
            contract.child_id = child_id
            parent_link_res = await db.execute(
                select(ParentChild).where(ParentChild.child_id == child_id)
            )
            parent_link = parent_link_res.scalars().first()
            if parent_link:
                contract.parent_id = parent_link.parent_id
            contract.match_status = "matched"
            await _mark_child_as_active_client(db, child_id)

    # Как только заполнены все основные поля — договор считается
    # оформленным, статус переключается на «Действующий».
    core_fields = [
        contract.start_date, contract.end_date, contract.parent_full_name,
        contract.parent_phone, contract.city, contract.street, contract.house,
    ]
    if all(bool(v) for v in core_fields):
        contract.is_signed = True

    await db.commit()

    result = await db.execute(
        select(ParentContract).options(
            joinedload(ParentContract.parent).joinedload(ParentProfile.user),
            joinedload(ParentContract.child).joinedload(ChildProfile.user),
            joinedload(ParentContract.extra_children).joinedload(ParentContractChild.child).joinedload(ChildProfile.user),
        ).where(ParentContract.id == contract_id)
    )
    return _serialize_contract(result.unique().scalar_one())


class ContractAssignChild(BaseModel):
    child_ids: List[int]


@router.post("/contracts/{contract_id}/assign-child", dependencies=[Depends(require_admin)])
async def assign_contract_child(
    contract_id: int, payload: ContractAssignChild, db: AsyncSession = Depends(get_db)
):
    """Вручную привязать договор к одному или нескольким ученикам (например,
    брат и сестра на одном договоре), если автоматическая привязка не сработала."""
    if not payload.child_ids:
        raise HTTPException(status_code=400, detail="Нужно указать хотя бы одного ученика")

    result = await db.execute(select(ParentContract).where(ParentContract.id == contract_id))
    contract = result.scalar_one_or_none()
    if not contract:
        raise HTTPException(status_code=404, detail="Договор не найден")

    children_res = await db.execute(
        select(ChildProfile.id).where(ChildProfile.id.in_(payload.child_ids))
    )
    valid_ids = {row[0] for row in children_res.all()}
    if valid_ids != set(payload.child_ids):
        raise HTTPException(status_code=404, detail="Один или несколько учеников не найдены")

    await db.execute(
        ParentContractChild.__table__.delete().where(ParentContractChild.contract_id == contract_id)
    )
    for cid in payload.child_ids:
        db.add(ParentContractChild(contract_id=contract_id, child_id=cid))

    primary_id = payload.child_ids[0]
    contract.child_id = primary_id
    parent_link_res = await db.execute(
        select(ParentChild).where(ParentChild.child_id == primary_id)
    )
    parent_link = parent_link_res.scalars().first()
    contract.parent_id = parent_link.parent_id if parent_link else None
    contract.match_status = "matched"
    for cid in payload.child_ids:
        await _mark_child_as_active_client(db, cid)
    await db.commit()

    result = await db.execute(
        select(ParentContract).options(
            joinedload(ParentContract.parent).joinedload(ParentProfile.user),
            joinedload(ParentContract.child).joinedload(ChildProfile.user),
            joinedload(ParentContract.extra_children).joinedload(ParentContractChild.child).joinedload(ChildProfile.user),
        ).where(ParentContract.id == contract_id)
    )
    return _serialize_contract(result.unique().scalar_one())


@router.post("/contracts/{contract_id}/recalculate", dependencies=[Depends(require_admin)])
async def recalculate_contract(
    contract_id: int,
    as_of: Optional[date] = Query(None, description="Дата, на которую считать рекомендацию (по умолчанию — сегодня)"),
    db: AsyncSession = Depends(get_db),
):
    """Пересчитать рекомендацию по договору на указанную дату (для теста —
    можно указать любую прошедшую дату, например ?as_of=2026-08-30)."""
    result = await db.execute(select(ParentContract).where(ParentContract.id == contract_id))
    contract = result.scalar_one_or_none()
    if not contract:
        raise HTTPException(status_code=404, detail="Договор не найден")

    check_date = as_of or date.today()
    recommendation, skip_reason = await _compute_recommendation(db, contract, check_date)
    if recommendation is not None:
        contract.recommendation = recommendation
        contract.recommendation_as_of = check_date
        await db.commit()

    result = await db.execute(
        select(ParentContract).options(
            joinedload(ParentContract.parent).joinedload(ParentProfile.user),
            joinedload(ParentContract.child).joinedload(ChildProfile.user),
            joinedload(ParentContract.extra_children).joinedload(ParentContractChild.child).joinedload(ChildProfile.user),
        ).where(ParentContract.id == contract_id)
    )
    row = _serialize_contract(result.unique().scalar_one())
    if skip_reason:
        row["skip_reason"] = skip_reason
    return row


async def recalculate_all_contracts(db: AsyncSession, as_of: Optional[date] = None) -> int:
    """Пересчитать рекомендации по всем привязанным к ученику договорам.
    Используется еженедельным фоновым заданием (каждое воскресенье)."""
    check_date = as_of or date.today()
    result = await db.execute(
        select(ParentContract).where(ParentContract.child_id.isnot(None))
    )
    updated = 0
    for contract in result.scalars().all():
        recommendation, _skip_reason = await _compute_recommendation(db, contract, check_date)
        if recommendation is not None:
            contract.recommendation = recommendation
            contract.recommendation_as_of = check_date
            updated += 1
    await db.commit()
    return updated


@router.post("/contracts/recalculate-all", dependencies=[Depends(require_admin)])
async def recalculate_all_contracts_endpoint(
    as_of: Optional[date] = Query(None),
    db: AsyncSession = Depends(get_db),
):
    updated = await recalculate_all_contracts(db, as_of)
    return {"updated": updated, "as_of": (as_of or date.today()).isoformat()}


@router.get("/contracts-dashboard", dependencies=[Depends(require_admin)])
async def contracts_dashboard(db: AsyncSession = Depends(get_db)):
    parent_result = await db.execute(
        select(ParentContract).options(
            joinedload(ParentContract.parent).joinedload(ParentProfile.user),
            joinedload(ParentContract.child).joinedload(ChildProfile.user),
            joinedload(ParentContract.extra_children).joinedload(ParentContractChild.child).joinedload(ChildProfile.user),
        )
    )
    return [_serialize_contract(c) for c in parent_result.scalars().unique().all()]


# ─── Ручная привязка Родитель ↔ Ребёнок ────────────────────────────────────────

@router.post("/parent-child/bind", dependencies=[Depends(require_admin)])
async def bind_parent_to_child(payload: BaseParentChildLink, db: AsyncSession = Depends(get_db)):
    """Вручную связать существующего родителя и ребёнка по ID их профилей (Admin only)."""

    # 1. Проверяем, существует ли родитель
    parent_res = await db.execute(select(ParentProfile).where(ParentProfile.id == payload.parent_id))
    parent = parent_res.scalar_one_or_none()
    if not parent:
        raise HTTPException(status_code=404, detail=f"Профиль родителя с ID {payload.parent_id} не найден")

    # 2. Проверяем, существует ли ребёнок
    child_res = await db.execute(select(ChildProfile).where(ChildProfile.id == payload.child_id))
    child = child_res.scalar_one_or_none()
    if not child:
        raise HTTPException(status_code=404, detail=f"Профиль ребёнка с ID {payload.child_id} не найден")

    # 3. Проверяем дубликаты связей
    exist_res = await db.execute(
        select(ParentChild).where(
            ParentChild.parent_id == payload.parent_id,
            ParentChild.child_id == payload.child_id
        )
    )
    if exist_res.scalar_one_or_none():
        return {"message": "Эта связь уже существует в базе данных"}

    # 4. Создаем запись
    new_relation = ParentChild(
        parent_id=payload.parent_id,
        child_id=payload.child_id
    )
    db.add(new_relation)
    await db.commit()

    return {
        "status": "success",
        "message": f"Родитель (ID {payload.parent_id}) успешно связан с ребёнком (ID {payload.child_id})"
    }


# ─── Tutors (admin management) ─────────────────────────────────────────────────

def _serialize_tutor(
    tutor: TutorProfile,
    earnings: Optional[float] = None,
    pending_rate: Optional[float] = None,
    pending_rate_from: Optional[date] = None,
) -> TutorProfileOut:
    """TutorProfile.subjects is a list of TutorSubject link rows, not Subject —
    unwrap them into the actual Subject objects expected by TutorProfileOut."""
    return TutorProfileOut(
        id=tutor.id,
        bio=tutor.bio,
        education=tutor.education,
        experience_years=tutor.experience_years,
        rate_per_hour=tutor.rate_per_hour,
        is_published=tutor.is_published,
        user=tutor.user,
        subjects=[ts.subject for ts in tutor.subjects if ts.subject is not None],
        earnings=earnings,
        pending_rate=pending_rate,
        pending_rate_from=pending_rate_from,
    )


async def _tutor_earnings_map(
    db: AsyncSession,
    tutor_ids: List[int],
    as_of: Optional[date] = None,
    histories: Optional[dict] = None,
) -> dict[int, float]:
    """Сколько должны каждому репетитору: (проведённые занятия * ставка,
    действовавшая на дату каждого занятия) - уже выплачено.
    Если as_of указан — считаются только занятия с датой не позже as_of (для расчёта
    суммы к оплате при выборе конкретной даты выплаты)."""
    if not tutor_ids:
        return {}

    earned_by_tutor = await compute_earnings_bulk(db, list(tutor_ids), as_of_date=as_of, histories=histories)

    paid_res = await db.execute(
        select(TutorPayout.tutor_id, func.sum(TutorPayout.amount))
        .where(TutorPayout.tutor_id.in_(tutor_ids))
        .group_by(TutorPayout.tutor_id)
    )
    paid_by_tutor = {row[0]: (row[1] or 0) for row in paid_res.all()}

    result = {}
    for tutor_id in tutor_ids:
        total_earned = earned_by_tutor.get(tutor_id, 0)
        paid = paid_by_tutor.get(tutor_id, 0)
        result[tutor_id] = round(max(0.0, total_earned - paid), 2)
    return result


@router.get("/tutors", response_model=List[TutorProfileOut], dependencies=[Depends(require_admin)])
async def list_admin_tutors(db: AsyncSession = Depends(get_db)):
    """Список всех репетиторов для админ-панели (вкладка «Репетиторы»)."""
    result = await db.execute(
        select(TutorProfile)
        .options(
            joinedload(TutorProfile.user),
            joinedload(TutorProfile.subjects).joinedload(TutorSubject.subject),
        )
        .where(TutorProfile.archived_at.is_(None))  # архив — отдельным списком
        .order_by(TutorProfile.id)
    )
    tutors = result.unique().scalars().all()
    # Всё одним набором запросов, а не по 4 запроса на каждого репетитора.
    histories = await load_rate_histories(db, [t.id for t in tutors])
    rates = {t.id: current_and_pending_from_history(histories.get(t.id) or [], t.rate_per_hour) for t in tutors}
    changed = False
    for t in tutors:
        _cur = rates[t.id][0]
        if _cur is not None and t.rate_per_hour != _cur:
            # запланированная ставка вступила в силу — обновляем поле в карточке
            t.rate_per_hour = _cur
            changed = True
    if changed:
        await db.commit()
    earnings_map = await _tutor_earnings_map(db, [t.id for t in tutors], histories=histories)
    rows = []
    for t in tutors:
        _cur, pending, pending_from = rates[t.id]
        rows.append(_serialize_tutor(
            t, earnings=earnings_map.get(t.id, 0.0),
            pending_rate=pending, pending_rate_from=pending_from,
        ))
    return rows


class TutorRateChange(BaseModel):
    rate_per_hour: float
    effective_from: date


@router.post(
    "/tutors/{tutor_id}/rate-change",
    response_model=TutorProfileOut,
    dependencies=[Depends(require_admin)],
)
async def change_tutor_rate(
    tutor_id: int,
    payload: TutorRateChange,
    db: AsyncSession = Depends(get_db),
):
    """Изменить ставку репетитора с конкретной даты — занятия до этой даты
    по-прежнему считаются по старой ставке, начиная с неё — по новой.
    Не пересчитывает задним числом уже проведённые занятия."""
    tutor_res = await db.execute(select(TutorProfile).where(TutorProfile.id == tutor_id))
    tutor = tutor_res.scalar_one_or_none()
    if not tutor:
        raise HTTPException(status_code=404, detail=f"Репетитор с ID {tutor_id} не найден")
    if payload.rate_per_hour <= 0:
        raise HTTPException(status_code=400, detail="Ставка должна быть больше нуля")

    # Если у репетитора ещё нет истории ставок — сначала фиксируем его
    # ТЕКУЩУЮ ставку как действовавшую с самого раннего занятия (или с
    # сегодня, если занятий ещё не было), чтобы прошлые занятия не съехали
    # на новую ставку задним числом.
    existing_res = await db.execute(
        select(TutorRateHistory.id).where(TutorRateHistory.tutor_id == tutor_id)
    )
    has_history = existing_res.first() is not None
    if not has_history and tutor.rate_per_hour:
        earliest_lesson_res = await db.execute(
            select(func.min(Lesson.date)).where(Lesson.tutor_id == tutor_id)
        )
        earliest_date = earliest_lesson_res.scalar() or date.today()
        db.add(TutorRateHistory(
            tutor_id=tutor_id,
            rate_per_hour=tutor.rate_per_hour,
            effective_from=earliest_date,
        ))

    db.add(TutorRateHistory(
        tutor_id=tutor_id,
        rate_per_hour=payload.rate_per_hour,
        effective_from=payload.effective_from,
    ))
    await db.flush()

    # tutor.rate_per_hour отражает ставку, действующую СЕГОДНЯ — если новая
    # ставка ещё не наступила (дата в будущем), поле не меняется, а новая
    # ставка видна отдельно как "запланированная" (pending_rate).
    current_rate, pending_rate, pending_rate_from = await get_current_and_pending_rate(
        db, tutor_id, tutor.rate_per_hour
    )
    tutor.rate_per_hour = current_rate
    await db.commit()

    result = await db.execute(
        select(TutorProfile).options(
            joinedload(TutorProfile.user),
            joinedload(TutorProfile.subjects).joinedload(TutorSubject.subject),
        ).where(TutorProfile.id == tutor_id)
    )
    tutor = result.unique().scalar_one()
    earnings_map = await _tutor_earnings_map(db, [tutor.id])
    return _serialize_tutor(
        tutor, earnings=earnings_map.get(tutor.id, 0.0),
        pending_rate=pending_rate, pending_rate_from=pending_rate_from,
    )


@router.patch("/tutors/{tutor_id}", response_model=TutorProfileOut, dependencies=[Depends(require_admin)])
async def update_admin_tutor(
    tutor_id: int,
    payload: AdminTutorUpdate,
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(TutorProfile)
        .options(
            joinedload(TutorProfile.user),
            joinedload(TutorProfile.subjects).joinedload(TutorSubject.subject),
        )
        .where(TutorProfile.id == tutor_id)
    )
    tutor = result.unique().scalar_one_or_none()
    if not tutor:
        raise HTTPException(status_code=404, detail=f"Репетитор с ID {tutor_id} не найден")

    data = payload.model_dump(exclude_unset=True)

    # Профильные поля репетитора
    for field in ("bio", "education", "experience_years", "is_published"):
        if field in data and data[field] is not None:
            setattr(tutor, field, data[field])
    # Ставка: если у репетитора есть история ставок, ручная правка записывается
    # в историю с сегодняшнего дня (иначе расчёт заработка её бы не увидел).
    if data.get("rate_per_hour") is not None and data["rate_per_hour"] != tutor.rate_per_hour:
        from app.services.tutor_earnings import set_tutor_rate_from, minsk_today
        has_hist = (await db.execute(
            select(TutorRateHistory.id).where(TutorRateHistory.tutor_id == tutor.id).limit(1)
        )).first() is not None
        if has_hist:
            await set_tutor_rate_from(db, tutor, data["rate_per_hour"], minsk_today())
        tutor.rate_per_hour = data["rate_per_hour"]

    # Поля связанного пользователя (имя, фамилия, аватар)
    user_data = data.get("user")
    if user_data:
        for field in ("first_name", "last_name", "avatar_url"):
            if user_data.get(field) is not None:
                setattr(tutor.user, field, user_data[field])

    # Предметы репетитора — полностью пересобираем список связей
    subject_ids = data.get("subject_ids")
    if subject_ids is not None:
        existing = await db.execute(
            select(TutorSubject).where(TutorSubject.tutor_id == tutor.id)
        )
        for link in existing.scalars().all():
            await db.delete(link)
        await db.flush()

        if subject_ids:
            valid_subjects = await db.execute(
                select(Subject.id).where(Subject.id.in_(subject_ids))
            )
            valid_ids = {row[0] for row in valid_subjects.all()}
            for sid in subject_ids:
                if sid in valid_ids:
                    db.add(TutorSubject(tutor_id=tutor.id, subject_id=sid))

    await db.commit()

    # Перечитываем с подгруженными связями для корректного ответа
    result = await db.execute(
        select(TutorProfile)
        .options(
            joinedload(TutorProfile.user),
            joinedload(TutorProfile.subjects).joinedload(TutorSubject.subject),
        )
        .where(TutorProfile.id == tutor_id)
    )
    tutor = result.unique().scalar_one()
    earnings_map = await _tutor_earnings_map(db, [tutor.id])
    _cur, pending_rate, pending_rate_from = await get_current_and_pending_rate(db, tutor.id, tutor.rate_per_hour)
    return _serialize_tutor(
        tutor, earnings=earnings_map.get(tutor.id, 0.0),
        pending_rate=pending_rate, pending_rate_from=pending_rate_from,
    )


@router.post("/tutors/{tutor_id}/pay", response_model=TutorPayoutOut, dependencies=[Depends(require_admin)])
async def pay_admin_tutor(
    tutor_id: int,
    payload: TutorPayoutCreate,
    db: AsyncSession = Depends(get_db),
):
    """Отметить зарплату репетитору как выплаченную на выбранную дату.
    Оплачивается только то, что заработано занятиями с датой не позже выбранной
    (payload.paid_at) — не весь текущий баланс на сегодня. Остаток за занятия
    после этой даты продолжает числиться как долг."""
    tutor_res = await db.execute(select(TutorProfile).where(TutorProfile.id == tutor_id))
    tutor = tutor_res.scalar_one_or_none()
    if not tutor:
        raise HTTPException(status_code=404, detail=f"Репетитор с ID {tutor_id} не найден")

    earnings_map = await _tutor_earnings_map(db, [tutor_id], as_of=payload.paid_at)
    outstanding = earnings_map.get(tutor_id, 0.0)
    if outstanding <= 0:
        raise HTTPException(status_code=400, detail="На выбранную дату этому репетитору нечего платить")

    payout = TutorPayout(tutor_id=tutor_id, amount=outstanding, paid_at=payload.paid_at)
    db.add(payout)
    if tutor.user_id:
        db.add(Notification(
            user_id=tutor.user_id,
            title="Зарплата выплачена",
            body=f"Вам выплачено {outstanding} BYN за {payload.paid_at}.",
        ))
    await db.commit()
    await db.refresh(payout)

    remaining_map = await _tutor_earnings_map(db, [tutor_id])
    return TutorPayoutOut(
        id=payout.id,
        tutor_id=payout.tutor_id,
        amount=payout.amount,
        paid_at=payout.paid_at,
        created_at=payout.created_at,
        earnings_after=remaining_map.get(tutor_id, 0.0),
    )


@router.delete("/tutors/{tutor_id}", status_code=204, dependencies=[Depends(require_admin)])
async def delete_admin_tutor(tutor_id: int, db: AsyncSession = Depends(get_db)):
    """«Удалить» репетитора = перенести в архив.
    • Удаляются только его будущие запланированные занятия (и ДЗ к ним).
    • Прошлые занятия, отчёты, ДЗ, оплаты родителей, выплаты и ставки
      репетитора остаются как были — с его именем у родителей и учеников,
      в аналитике, частотности и бюджете ничего не меняется.
    • Войти он больше не может, в списках репетиторов и при создании
      занятий не показывается, с сайта снимается. Можно восстановить."""
    from datetime import datetime as _dt
    from app.services.pricing import minsk_today
    tutor = await db.scalar(select(TutorProfile).where(TutorProfile.id == tutor_id))
    if not tutor:
        raise HTTPException(status_code=404, detail=f"Репетитор с ID {tutor_id} не найден")
    today = minsk_today()
    now_t = (_dt.utcnow() + timedelta(hours=3)).time()
    future = (await db.execute(
        select(Lesson).where(
            Lesson.tutor_id == tutor_id,
            Lesson.status == LessonStatus.scheduled,
            or_(Lesson.date > today, (Lesson.date == today) & (Lesson.time_start > now_t)),
        )
    )).scalars().all()
    for lesson in future:
        for hw in (await db.execute(select(Homework).where(Homework.lesson_id == lesson.id))).scalars().all():
            await db.delete(hw)
        for rpt in (await db.execute(select(Report).where(Report.lesson_id == lesson.id))).scalars().all():
            rpt.lesson_id = None  # отчёт сохраняем, просто без привязки к удалённому занятию
        await db.delete(lesson)
    tutor.archived_at = _dt.utcnow()
    tutor.is_published = False
    user = await db.get(User, tutor.user_id) if tutor.user_id else None
    if user:
        user.is_active = False
    await db.commit()
    return None


@router.get("/tutors/archived", dependencies=[Depends(require_admin)])
async def list_archived_tutors(db: AsyncSession = Depends(get_db)):
    """Архив репетиторов: кто, когда перенесён, сколько прошлых занятий и сколько ему ещё должны."""
    rows = (await db.execute(
        select(TutorProfile.id, User.last_name, User.first_name, TutorProfile.archived_at)
        .join(User, User.id == TutorProfile.user_id)
        .where(TutorProfile.archived_at.isnot(None))
        .order_by(TutorProfile.archived_at.desc())
    )).all()
    ids = [r[0] for r in rows]
    owed = await _tutor_earnings_map(db, ids) if ids else {}
    counts = dict((await db.execute(
        select(Lesson.tutor_id, func.count(Lesson.id)).where(Lesson.tutor_id.in_(ids or [0])).group_by(Lesson.tutor_id)
    )).all())
    return [{"id": tid, "name": f"{ln or ''} {fn or ''}".strip(), "archived_at": at.isoformat() + "Z" if at else None,
             "lessons": int(counts.get(tid, 0)), "owed": round(float(owed.get(tid, 0.0)), 2)} for tid, ln, fn, at in rows]


@router.post("/tutors/{tutor_id}/restore", dependencies=[Depends(require_admin)])
async def restore_archived_tutor(tutor_id: int, db: AsyncSession = Depends(get_db)):
    tutor = await db.scalar(select(TutorProfile).where(TutorProfile.id == tutor_id))
    if not tutor:
        raise HTTPException(status_code=404, detail="Репетитор не найден")
    tutor.archived_at = None
    user = await db.get(User, tutor.user_id) if tutor.user_id else None
    if user:
        user.is_active = True
    await db.commit()
    return {"ok": True}


@router.delete("/students/{user_id}", status_code=204, dependencies=[Depends(require_admin)])
async def delete_admin_student(user_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.id == user_id, User.role == RoleEnum.child))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="Student not found")

    student_descriptions = {
        f"{user.last_name} {user.first_name}".strip(),
        f"{user.first_name} {user.last_name}".strip(),
    }

    result = await db.execute(select(ChildProfile).where(ChildProfile.user_id == user_id))
    child = result.scalar_one_or_none()
    if not child:
        await _delete_invite_codes_for_user(db, user_id)
        await _delete_invite_codes_for_descriptions(db, student_descriptions)
        notifications = await db.execute(select(Notification).where(Notification.user_id == user_id))
        for notification in notifications.scalars().all():
            await db.delete(notification)
        await db.delete(user)
        await db.commit()
        return None

    child_id = child.id

    parent_links = await db.execute(select(ParentChild).where(ParentChild.child_id == child_id))
    for link in parent_links.scalars().all():
        await db.delete(link)

    lessons = await db.execute(select(Lesson).where(Lesson.child_id == child_id))
    for lesson in lessons.scalars().all():
        hws = await db.execute(select(Homework).where(Homework.lesson_id == lesson.id))
        for hw in hws.scalars().all():
            await db.delete(hw)
        await db.delete(lesson)

    for model, field in (
        (Report, Report.child_id),
        (Material, Material.child_id),
        (Homework, Homework.child_id),
        (ParentContract, ParentContract.child_id),
        (Payment, Payment.child_id),
        (Comment, Comment.child_id),
        (TestResult, TestResult.child_id),
        (QmCall, QmCall.child_id),
        (QmRegularity, QmRegularity.child_id),
    ):
        rows = await db.execute(select(model).where(field == child_id))
        for row in rows.scalars().all():
            await db.delete(row)

    receipts = await db.execute(select(EmailReceipt).where(EmailReceipt.child_id == child_id))
    for receipt in receipts.scalars().all():
        receipt.child_id = None

    await _delete_invite_codes_for_user(db, user_id)
    await _delete_invite_codes_for_descriptions(db, student_descriptions)

    notifications = await db.execute(select(Notification).where(Notification.user_id == user_id))
    for notification in notifications.scalars().all():
        await db.delete(notification)

    await db.delete(child)
    await db.delete(user)
    await db.commit()
    return None


# ─── Tutor documents (admin → tutor PDF exchange) ──────────────────────────────

@router.post(
    "/tutor-documents",
    response_model=TutorDocumentOut,
    status_code=201,
    dependencies=[Depends(require_admin)],
)
async def send_tutor_document(payload: TutorDocumentCreate, db: AsyncSession = Depends(get_db)):
    """Админ отправляет документ (например, PDF) выбранному репетитору."""
    tutor_res = await db.execute(select(TutorProfile).where(TutorProfile.id == payload.tutor_id))
    if not tutor_res.scalar_one_or_none():
        raise HTTPException(status_code=404, detail=f"Репетитор с ID {payload.tutor_id} не найден")

    doc = TutorDocument(tutor_id=payload.tutor_id, title=payload.title, file_url=payload.file_url)
    db.add(doc)
    await db.commit()
    await db.refresh(doc)
    return doc


@router.post("/tutors/{tutor_id}/work-documents", dependencies=[Depends(require_admin)])
async def send_tutor_work_document(
    tutor_id: int,
    payload: TutorWorkDocumentCreate,
    db: AsyncSession = Depends(get_db),
):
    """Админ отправляет репетитору контракт, акт или обычный документ."""
    tutor_res = await db.execute(select(TutorProfile).where(TutorProfile.id == tutor_id))
    if not tutor_res.scalar_one_or_none():
        raise HTTPException(status_code=404, detail=f"Репетитор с ID {tutor_id} не найден")

    kind = payload.kind.strip().lower()
    if kind in {"contract", "контракт", "договор", "договор подряда"}:
        item = TutorContract(tutor_id=tutor_id, file_url=payload.file_url)
        db.add(item)
        stored_kind = "contract"
    elif kind in {"act", "акт"}:
        today = date.today()
        item = Act(
            tutor_id=tutor_id,
            period_start=today.replace(day=1),
            period_end=today,
            lessons_count=0,
            total_amount=0,
            blank_url=payload.file_url,
        )
        db.add(item)
        stored_kind = "act"
    else:
        item = TutorDocument(tutor_id=tutor_id, title=payload.title, file_url=payload.file_url)
        db.add(item)
        stored_kind = "document"

    await db.commit()
    await db.refresh(item)
    return {"ok": True, "kind": stored_kind, "id": item.id}


@router.get(
    "/tutor-documents",
    response_model=List[TutorDocumentOut],
    dependencies=[Depends(require_admin)],
)
async def list_tutor_documents(
    tutor_id: Optional[int] = Query(None),
    db: AsyncSession = Depends(get_db),
):
    """Список документов, отправленных репетиторам (можно отфильтровать по репетитору)."""
    q = select(TutorDocument)
    if tutor_id:
        q = q.where(TutorDocument.tutor_id == tutor_id)
    result = await db.execute(q.order_by(TutorDocument.created_at.desc()))
    return result.scalars().all()


# ─── Acts (просмотр подписанных актов от репетиторов) ──────────────────────────

@router.get("/acts", response_model=List[ActOut], dependencies=[Depends(require_admin)])
async def list_admin_acts(
    tutor_id: Optional[int] = Query(None),
    db: AsyncSession = Depends(get_db),
):
    """Список актов (в т.ч. подписанных репетитором), можно отфильтровать по репетитору."""
    q = select(Act)
    if tutor_id:
        q = q.where(Act.tutor_id == tutor_id)
    result = await db.execute(q.order_by(Act.created_at.desc()))
    return result.scalars().all()


# ─── Отчёт: ученики без занятий N дней (выгрузка в Excel) ──────────────────────

@router.get("/reports/inactive-students.xlsx", dependencies=[Depends(require_admin)])
async def inactive_students_report(
    days: int = Query(5, description="Порог в днях с последнего проведённого занятия"),
    db: AsyncSession = Depends(get_db),
):
    """Список учеников, у которых последнее занятие со статусом «проведено»
    было больше days дней назад (или таких занятий не было вообще) —
    чтобы понять, кто сейчас фактически не занимается. Отдаёт готовый
    .xlsx файл на скачивание."""
    from openpyxl import Workbook
    from openpyxl.styles import Font

    cutoff = date.today() - timedelta(days=days)

    # Учитываются только действующие клиенты (CRM-статус «Клиент»)
    children_res = await db.execute(
        select(ChildProfile, User).join(User, ChildProfile.user_id == User.id)
        .where(ChildProfile.crm_status == "Клиент", User.is_active.isnot(False))
    )
    children = children_res.all()

    rows = []
    for child, user in children:
        last_res = await db.execute(
            select(func.max(Lesson.date)).where(
                Lesson.child_id == child.id,
                Lesson.status == LessonStatus.completed,
            )
        )
        last_date = last_res.scalar()
        if last_date is None or last_date < cutoff:
            rows.append((
                f"{user.last_name} {user.first_name}".strip(),
                child.crm_status,
                last_date.isoformat() if last_date else "никогда",
                (date.today() - last_date).days if last_date else "",
            ))

    rows.sort(key=lambda r: (r[3] == "", -(r[3] if isinstance(r[3], int) else 0)))

    wb = Workbook()
    ws = wb.active
    ws.title = "Не занимаются"
    headers = ["Ученик", "Статус в CRM", "Последнее проведённое занятие", "Дней без занятий"]
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True)
    for row in rows:
        ws.append(row)
    for col_cells in ws.columns:
        width = max(len(str(c.value)) for c in col_cells if c.value is not None) + 2
        ws.column_dimensions[col_cells[0].column_letter].width = max(width, 12)

    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)

    filename = f"inactive-students-{date.today().isoformat()}.xlsx"
    return StreamingResponse(
        buffer,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/email-diagnostics")
async def email_diagnostics(_: User = Depends(require_admin)):
    """Проверка настройки почты для уведомлений о заявках с сайта — какие
    переменные окружения заполнены на сервере (сами значения, кроме адресов,
    не показываются) и пробная отправка письма. Помогает быстро понять,
    почему заявки не долетают на почту, не заглядывая в Render вручную."""
    import smtplib
    from app.services import email_notification as en

    env_status = {
        "EMAIL_USER": bool(en.EMAIL_USER),
        "EMAIL_USER_value": en.EMAIL_USER or None,
        "EMAIL_PASSWORD": bool(en.EMAIL_PASSWORD),
        "EMAIL_SMTP_HOST": en.SMTP_HOST,
        "EMAIL_SMTP_PORT": en.SMTP_PORT,
        "NOTIFICATION_EMAIL": bool(en.NOTIFICATION_EMAIL),
        "NOTIFICATION_EMAIL_value": en.NOTIFICATION_EMAIL or None,
    }

    if not en.EMAIL_USER or not en.EMAIL_PASSWORD or not en.NOTIFICATION_EMAIL:
        return {
            "configured": False,
            "env": env_status,
            "error": "Не заполнены переменные окружения EMAIL_USER / EMAIL_PASSWORD / NOTIFICATION_EMAIL на сервере (Render → pifagor-api → Environment).",
        }

    test_error = None
    try:
        with smtplib.SMTP(en.SMTP_HOST, en.SMTP_PORT, timeout=15) as server:
            server.starttls()
            server.login(en.EMAIL_USER, en.EMAIL_PASSWORD)
    except smtplib.SMTPAuthenticationError as e:
        test_error = (
            "Ошибка авторизации на почтовом сервере — неверный логин/пароль. "
            "Если это Gmail, EMAIL_PASSWORD должен быть паролем приложения "
            "(App Password, 16 символов), а не обычным паролем от аккаунта. "
            f"Подробности: {e}"
        )
    except Exception as e:
        test_error = f"Не удалось подключиться к почтовому серверу: {e}"

    return {
        "configured": test_error is None,
        "env": env_status,
        "error": test_error,
    }

@router.get("/leads-diagnostics")
async def leads_diagnostics(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
):
    """Прямая проверка таблицы lead_requests через сырой SQL — чтобы понять,
    реально ли заявки не сохраняются, или это где-то кэшируется ответ
    на фронте/прокси. Показывает количество строк и последние 5 заявок
    напрямую из базы, в обход ORM-связей."""
    from sqlalchemy import text

    count_result = await db.execute(text("SELECT COUNT(*) FROM lead_requests"))
    total = count_result.scalar_one()

    rows_result = await db.execute(
        text(
            "SELECT id, name, phone, email, subject_id, message, status, created_at "
            "FROM lead_requests ORDER BY created_at DESC LIMIT 5"
        )
    )
    rows = [dict(r._mapping) for r in rows_result.fetchall()]
    for r in rows:
        if r.get("created_at") is not None:
            r["created_at"] = str(r["created_at"])

    db_url = str(db.bind.engine.url) if hasattr(db, "bind") else None

    return {
        "total_rows_in_table": total,
        "last_5_rows": rows,
        "db_host": db.get_bind().engine.url.host if db.get_bind() else None,
    }

